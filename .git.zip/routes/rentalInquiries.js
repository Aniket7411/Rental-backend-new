// This file is not used directly - rental inquiries are handled through admin routes
module.exports = {};

